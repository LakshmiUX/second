package facts;
import java.io.File;
import java.util.ArrayList;
import java.util.Scanner;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Document;

public class Client {
		
	 
	public static void main(String[] args) 
	
	{
		try {
		//Reading in the file 
		File file = new File("C://Users//Lakshmi//eclipse-workspace//factsProject//src//facts.xml");
		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
		DocumentBuilder db = dbf.newDocumentBuilder();
		Document doc = db.parse(file); 
		
		//object for using FactList search method 
		FactList object = new FactList(); 
		
		System.out.println("Choose an option: \n1: New search - Random fact \n2: Search history \n3. Exit");
		Scanner l = new Scanner(System.in);
		int k = l.nextInt();
		String parameter = k + ""; 
		if (k<1 || k >= 4)
		{
			System.out.println("Please enter a valid number.");
		}
		if (k == 3)
		{
			System.out.println("You have exited the program successfully."); 
			System.exit(0);  
		}
		
        
		//Taking in input 
		
		
		
		Fact objectTwo = new Fact(); 
		
	
		//Printing
		if(k == 1)
		{
			Scanner d = new Scanner(System.in);
			System.out.println("Please enter keyword: ");
			String b = d.nextLine(); 
			
			Scanner yy = new Scanner(System.in);
			System.out.println("Please pick one of the following choices: \n1: Search by text \n2: Search by author \n3: Search by type \n4: Search randomly");
			int o = yy.nextInt();
			
			
				if (b != null && !b.equals("")){  // Received a search request
					int searchModeVal = FactSearchMode.ALL_VAL; // Default
						if(o == 4)
						{
							System.out.println(object.getRandom()); 						}
						FactList list = new FactList(); 
						FactList results = list.search(b, searchModeVal);
						Fact temp;
						if (results.getSize() == 0){
							System.out.println("Not Found!");
					}
						else
					{		
						
							for (int i = 0; i < results.getSize() ; i++){
								temp = results.get(i);
								System.out.println(temp.getText());
								System.out.println(temp.getAuthor());
								System.out.println(temp.getType());
						}
							
					}
			}
			
			
			
		}
			
		else if (k ==2)
		{
			System.out.println("This is your search history.");
			//Print search history
			ArrayList<String> searchList = new ArrayList(); 
			String searchTmp = "";
	
			for (int i = 0; i < searchList.size(); i++)
			{  
			searchTmp = searchList.get(i);
			System.out.println(searchTmp + " ");  
		}
		
		}
		}
		
			catch (Exception e)
		{
			System.out.println("Could not find file."); 
			e.printStackTrace(); 
			
		}
		
	
	}

}
